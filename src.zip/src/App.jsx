import Translator from './components/Translator'
import './App.css'

function App() {
  return (
    <div className="App">
      <Translator />
    </div>
  )
}

export default App
